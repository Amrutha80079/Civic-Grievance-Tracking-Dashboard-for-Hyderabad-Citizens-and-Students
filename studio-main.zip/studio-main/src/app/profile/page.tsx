
"use client";

// This page has been removed.

export default function ProfilePage() {
  return null;
}
