
export const firebaseConfig = {
  "projectId": "studio-687393081-9652d",
  "appId": "1:3289643972:web:27a64f4d405030326bc291",
  "storageBucket": "studio-687393081-9652d.appspot.com",
  "apiKey": "AIzaSyC3rF8E_uRgnB8Tg53L6_rW_D5zUYWZ8xc",
  "authDomain": "studio-687393081-9652d.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "3289643972"
};
