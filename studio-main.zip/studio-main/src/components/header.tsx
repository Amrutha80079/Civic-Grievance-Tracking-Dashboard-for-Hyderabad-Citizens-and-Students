// This file is intentionally left blank.
// The header logic has been split into HeaderLayout and HeaderNav
// to resolve a persistent hydration error.
